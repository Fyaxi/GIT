INSERT INTO forma_pagamento (id,nome,ativo,created_at,updated_at) VALUES (1,'DIVIDIR PAGAMENTO','','','');
