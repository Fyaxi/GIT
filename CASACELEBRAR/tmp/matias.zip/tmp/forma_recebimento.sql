INSERT INTO forma_recebimento (id,nome,ativo,created_at,updated_at) VALUES (1,'DIVIDIR RECEBIMENTO','','','');
