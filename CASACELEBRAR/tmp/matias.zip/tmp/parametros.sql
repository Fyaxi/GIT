INSERT INTO parametros (id,nome,valor) VALUES (1,'RotinaCaixa',0);
