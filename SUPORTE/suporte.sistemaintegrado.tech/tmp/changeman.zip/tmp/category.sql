INSERT INTO category (id,description) VALUES (1,'Bug');
INSERT INTO category (id,description) VALUES (2,'New feature');
INSERT INTO category (id,description) VALUES (3,'Improvement');
INSERT INTO category (id,description) VALUES (4,'Task');
INSERT INTO category (id,description) VALUES (5,'Support');
