INSERT INTO note (id,id_issue,id_user,note,register_date,register_time) VALUES (1,10,1,'<p>asdasd</p>','2021-07-16','14:53');
