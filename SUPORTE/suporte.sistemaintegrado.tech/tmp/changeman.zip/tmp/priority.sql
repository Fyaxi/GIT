INSERT INTO priority (id,description) VALUES (1,'Low');
INSERT INTO priority (id,description) VALUES (2,'Normal');
INSERT INTO priority (id,description) VALUES (3,'High');
INSERT INTO priority (id,description) VALUES (4,'Urgent');
