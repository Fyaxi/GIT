INSERT INTO project (id,description) VALUES (1,'Sistema Integrado - ERP');
