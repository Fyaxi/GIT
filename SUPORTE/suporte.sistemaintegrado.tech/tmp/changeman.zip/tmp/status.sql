INSERT INTO status (id,description,final_state,color) VALUES (1,'New','N','#4d993a');
INSERT INTO status (id,description,final_state,color) VALUES (2,'In progress','N','');
INSERT INTO status (id,description,final_state,color) VALUES (3,'Waiting feedback','N','#ff8514');
INSERT INTO status (id,description,final_state,color) VALUES (4,'Resolved','N','');
INSERT INTO status (id,description,final_state,color) VALUES (5,'Testing','N','');
INSERT INTO status (id,description,final_state,color) VALUES (6,'Deploy','N','');
INSERT INTO status (id,description,final_state,color) VALUES (7,'Closed','Y','#5761ba');
INSERT INTO status (id,description,final_state,color) VALUES (8,'Rejected','Y','#ff1414');
